from _typeshed import Self


class Pipeline:
    def __init__(self):
        